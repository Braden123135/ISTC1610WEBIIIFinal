<?php
    require "header.php";
?>
<!DOCTYPE html>
<html>
    <head>
        <title>phpscriptwillresolvetitle</title>
        <link rel="stylesheet" type="text/css" href="../Css/Profile.css">
    </head>
    <body>
        <div id="body_div">
            <div id="body_profile_div">
                <div id="body_profilecover_div">
                    <img id="body_profilecover_pfp_img" class="imgs" src="phpscriptwillresolvethis">
                    <h2 id="body_profilecover_uid_txt" class="txt">phpscriptwillresolvethis</h2>
                <div>

                <div id="body_profilecontent_div">

                </div>
            </div>
        </div> 
    </body>
</html>