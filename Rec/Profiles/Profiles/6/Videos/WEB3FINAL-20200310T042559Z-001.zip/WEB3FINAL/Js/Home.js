/* What does this script handle?
- Show/hide following tab
*/
var showFollowing = true;
var followingDiv;
var followingBackImg;

function followingVisible(){
    if(showFollowing){
        followingDiv.style.display = 'flex';
    }else{
        followingDiv.style.display = 'none';
    }
}

function changeFollowingVisibility(){
    if(showFollowing){
        showFollowing = false;
        console.log('hi');
    }else if (!showFollowing){
        showFollowing = true;
        console.log('ho');
    }
    followingVisible();
}


(function(window, document, undefined){

    // code that should be taken care of right away
    
    window.onload = init;
    
      function init(){
        // the code to be called when the dom has loaded
        // #document has its nodes

        console.log("hello");
        followingDiv = document.getElementById('body_home_following_div');
        console.log(followingDiv.id);
        followingBackImg = document.getElementById('body_back_img');
      }
    
 })(window, document, undefined);
